Set-Location $env:SYSTEM_DEFAULTWORKINGDIRECTORY\Package\Platform

New-AzResourceGroupDeployment -ResourceGroupName $env:ResourceGroupName -TemplateFile .\Templates\vnet.json -Verbose