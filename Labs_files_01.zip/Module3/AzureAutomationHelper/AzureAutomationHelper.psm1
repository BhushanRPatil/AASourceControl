﻿Function Add-ValueToVariable
{
    param ([hashtable]$Hashtable,[string]$Name,[string]$Value)

    $Hashtable.Add($Name,$Value)

    return $Hashtable

}

Function Save-VariablesToFile
{
    param ([hashtable]$Hashtable,[string]$Path=".\Variables.json")

    $Hashtable | ConvertTo-Json | Out-File $Path -Force
}

Function ConvertPSObjectToHashtable
{
    param (
        [Parameter(ValueFromPipeline)]
        $InputObject
    )

    process
    {
        if ($null -eq $InputObject) { return $null }

        if ($InputObject -is [System.Collections.IEnumerable] -and $InputObject -isnot [string])
        {
            $collection = @(
                foreach ($object in $InputObject) { ConvertPSObjectToHashtable $object }
            )

            Write-Output -NoEnumerate $collection
        }
        elseif ($InputObject -is [psobject])
        {
            $hash = @{}

            foreach ($property in $InputObject.PSObject.Properties)
            {
                $hash[$property.Name] = ConvertPSObjectToHashtable $property.Value
            }

            $hash
        }
        else
        {
            $InputObject
        }
    }
}

Function Monitor-CompilationJob
    {
        Param([guid]$JobID,[int]$Delay=5,$AutomationAccount)

        do
            {
                Write-Output "Checking status of job: $JobID"
                $job = Get-AzureRmAutomationDscCompilationJob -Id $JobID -ResourceGroupName $AutomationAccount.ResourceGroupName -AutomationAccountName $AutomationAccount.AutomationAccountName
                Write-Output "Status: $($job.Status)" 
                Start-Sleep -Seconds $Delay   
            }
        while ($job.Status -notmatch "Completed|Suspended")
        return $Matches[0]
    }

Function Import-CompileDSCConfiguration
    {

    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$true,HelpMessage="Provide a resource group name")]
        [string]$ResourceGroupName,

        [Parameter(Mandatory=$true,HelpMessage="Provide an automation account name")]
        [string]$AutomationAccountName,

        [Parameter(Mandatory=$true,HelpMessage="Provide the full path to a configuration file")]
        [ValidateScript({$_ -match "^\w:"})] # Cannot be a UNC path
        [string]$ConfigurationPath,
        [hashtable]$ConfigurationData,
        [switch]$Compile
    )

    try
        {
            $AutomationAccount = Get-AzureRmAutomationAccount -ResourceGroupName $ResourceGroupName -Name $AutomationAccountName -ErrorAction STOP
        }
    catch
        {
            Write-Output $Error[0].Exception
            exit
        }




    try
        {
            $AutomationAccount | Import-AzureRmAutomationDscConfiguration -SourcePath $ConfigurationPath `
                                                        -Published `
                                                        -ResourceGroupName $resourceGroupName `
                                                        -AutomationAccountName $automationAccountName `
                                                        -Force `
                                                        -Verbose `
                                                        -ErrorAction STOP
        }
    catch
        {
            Write-Output $Error[0].Exception
            exit 
        }
                                         

    if ($Compile)
        {
            $CompilationJob = $AutomationAccount | Start-AzureRmAutomationDscCompilationJob -ConfigurationName LabConfig -ConfigurationData $ConfigurationData -Verbose
            Monitor-CompilationJob -JobID $CompilationJob.Id -Delay 10 -AutomationAccount $AutomationAccount
        }

}

function Install-AzureAutomationModule
{

    [CmdletBinding()]
    Param(
        [string]$AutomationAccountName,
        [string]$AutomationAccountLocation,
        [string]$ResourceGroupName,
        [string]$AccountStatus="Existing",
        [string]$TemplateFile
        )

    $Params = @{
        "Automation Account Name" = $automationAccountName
        "Automation Account Location" = $location
        }

    $file = Get-Content $TemplateFile | ConvertFrom-Json
    if ($file.parameters.'New or existing Automation account' -ne $null)
        {
            $Params.Add("New or Existing Automation account",$AccountStatus)
        }

    New-AzureRmResourceGroupDeployment -ResourceGroupName $resourceGroupName `
                      -TemplateFile $TemplateFile `
                      -TemplateParameterObject $Params `
                      -Verbose

}

function Monitor-NodeStatus
{
    [CmdletBinding()]
    Param(
        $AutomationAccount,
        $NodeID,
        [switch]$AsJob,
        [string]$DesiredState,
        [int]$RetryCount = 10
        )
    
    $complete = $false
    $counter = 0
    
    if (!($AsJob))
    {
         do
         {
            try
            {
                $result = $AutomationAccount | Get-AzureRmAutomationDscNodeReport -NodeId $NodeID -ErrorAction STOP | Sort-Object EndTime -Descending | Select-Object -First 1 
            }
            catch
            {
                Write-Verbose "Report may not be generated yet"
                $result = $null
            }
            $test = $result.Status

            if ($test -ne $DesiredState)
            {
                if ($result -eq $null)
                    {
                        Write-Verbose "No results to display"
                    }
                else
                    {
                        Write-Verbose "Status: $($result.Status)"
                    }
                $counter++
                Write-Verbose "Attempt: $counter - Sleeping 30 seconds"
                Start-Sleep -Seconds 30
            }
            else
            {
                $complete = $true
            }    
         }
         while (($complete -ne $true) -or ($counter -ge $RetryCount))  
    }

} 

Export-ModuleMember -Function *