Param ([string]$Name)

Write-Output "Hello $Name"
Write-Output "This is my script Runbook"