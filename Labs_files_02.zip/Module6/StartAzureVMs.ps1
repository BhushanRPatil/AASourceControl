﻿param(    
    [Parameter(Mandatory = $false)] 
    [String] $ResourceGroupName
)
$connectionName = "AzureRunAsConnection"
$SubId = Get-AutomationVariable -Name 'AzureSubscriptionId'
try {
    # Get the connection "AzureRunAsConnection "
    $servicePrincipalConnection = Get-AutomationConnection -Name $connectionName         

    "Logging in to Azure..."
    Add-AzAccount `
        -ServicePrincipal `
        -TenantId $servicePrincipalConnection.TenantId `
        -ApplicationId $servicePrincipalConnection.ApplicationId `
        -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint
    "Setting context to a specific subscription"  
    Set-AzContext -SubscriptionId $SubId             
}
catch {
    if (!$servicePrincipalConnection) {
        $ErrorMessage = "Connection $connectionName not found."
        throw $ErrorMessage
    }
    else {
        Write-Error -Message $_.Exception
        throw $_.Exception
    }
}
# If there is a specific resource group, then get all VMs in the resource group,
# otherwise get all VMs in the subscription.
if ($ResourceGroupName) { 
    Write-Output "Resource Group specified: $($ResourceGroupName)"
    $VMs = Get-AzVM -ResourceGroupName $ResourceGroupName
}
else { 
    Write-Output "No Resource Group specified"
    $VMs = Get-AzVM
}

foreach ($VM in $VMs) {
    try {
        Write-Output "Starting VM: $($VM.Name)"
        $VM | Start-AzVM -ErrorAction Stop
        Write-Output ($VM.Name + " has been started")
    }
    catch {
        Write-Output ($VM.Name + " failed to start")
    }
}