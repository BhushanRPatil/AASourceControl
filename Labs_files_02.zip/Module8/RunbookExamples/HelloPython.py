import socket

print("Hello from " + socket.gethostname())
